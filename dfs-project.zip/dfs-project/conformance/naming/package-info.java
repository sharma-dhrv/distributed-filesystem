/** Conformance tests for the naming server. */
package conformance.naming;
